var fdLocale = {
        months:[
                "Enero",
                "Febrero",
                "Marzo",
                "Abril",
                "Mayo",
                "Junio",
                "Julio",
                "Agosto",
                "Septiembre",
                "Octubre",
                "Noviembre",
                "Diciembre"
                ],
        fullDay:[
                "Lunes",
                "Martes",
                "Mi\u00e9rcoles",
                "Jueves",
                "Viernes",
                "S\u00e1bado",
                "Domingo"
                ],
        /* Only stipulate the dayAbbr should the first letter of the fullDay not suffice

        dayAbbr:[],
        */

        /* Only stipulate the firstDayOfWeek should the first day not be Monday

        firstDayOfWeek:0,
        */
        titles:[
                "Mes Anterior",
                "Mes Siguiente",
                "A\u00f1o anterior",
                "A\u00f1o Siguiente",
                "Hoy"
                ]
};
